<?php
include("config.php");

if (isset($_POST['updatebarang'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kategori_id = $_POST['kategori'];
    $jumlahstok = $_POST['jumlahstok'];
    $harga = $_POST['harga'];
    $tanggalmasuk = $_POST['tanggalmasuk'];

    // Validasi nama hanya berisi huruf
    if (!preg_match("/^[a-zA-Z\s]+$/", $nama)) {
        echo "
            <script>
                alert('Nama hanya boleh berisi huruf dan spasi!');
                document.location.href = 'editbarang.php?id=$id';
            </script>
        ";
        exit();
    }

    // Validasi jumlah stok dan harga tidak negatif
    if ($jumlahstok < 0 || $harga < 0) {
        echo "
            <script>
                alert('Jumlah stok dan harga tidak boleh bernilai negatif!');
                document.location.href = 'editbarang.php?id=$id';
            </script>
        ";
        exit();
    }

    // Query update data
    $query = "UPDATE tabel_barang 
              SET nama = '$nama', kategori_id = '$kategori_id', jumlahstok = '$jumlahstok', harga = '$harga', tanggalmasuk = '$tanggalmasuk'
              WHERE id = '$id'";

    $result = mysqli_query($mysqli, $query);

    if ($result) {
        echo "
            <script>
                alert('Barang berhasil diupdate!');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal mengupdate barang: " . mysqli_error($mysqli) . "');
                document.location.href = 'editbarang.php?id=$id';
            </script>
        ";
    }
}
?>
