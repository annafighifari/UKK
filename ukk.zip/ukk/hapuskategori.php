<?php
include("config.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $queryNamaKategori = "SELECT nama_kategori FROM tabel_kategori WHERE id = $id";
    $resultNamaKategori = mysqli_query($mysqli, $queryNamaKategori);
    $kategori = mysqli_fetch_assoc($resultNamaKategori);

    if ($kategori) {
        $namaKategori = $kategori['nama_kategori'];

        $queryHapus = "DELETE FROM tabel_kategori WHERE id = $id";
        $resultHapus = mysqli_query($mysqli, $queryHapus);

        if ($resultHapus) {
            $queryReorder = "SET @num = 0; 
                             UPDATE tabel_kategori SET id = (@num := @num + 1);
                             ALTER TABLE tabel_kategori AUTO_INCREMENT = 1;";
            mysqli_multi_query($mysqli, $queryReorder);

            do {
                mysqli_next_result($mysqli);
            } while (mysqli_more_results($mysqli));

            $queryUpdateBarang = "UPDATE tabel_barang AS b
                                  JOIN tabel_kategori AS k ON b.kategori_id = k.id
                                  SET b.kategori_id = k.id
                                  WHERE k.nama_kategori = '$namaKategori'";
            mysqli_query($mysqli, $queryUpdateBarang);

            echo "
                <script>
                    alert('Kategori berhasil dihapus dan ID diurutkan ulang!');
                    document.location.href = 'daftarkategori.php';
                </script>
            ";
        } else {
            echo "
                <script>
                    alert('Gagal menghapus kategori: " . mysqli_error($mysqli) . "');
                    document.location.href = 'daftarkategori.php';
                </script>
            ";
        }
    } else {
        echo "
            <script>
                alert('Kategori tidak ditemukan!');
                document.location.href = 'daftarkategori.php';
            </script>
        ";
    }
} else {
    header("Location: daftarkategori.php");
    exit();
}
?>
