<?php
include("config.php");

$filter_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

$query = "SELECT b.id AS barang_id, k.id AS kategori_id, b.nama, k.nama_kategori, b.jumlahstok, b.harga, b.tanggalmasuk 
          FROM tabel_barang b 
          JOIN tabel_kategori k ON b.kategori_id = k.id";

if (!empty($filter_kategori)) {
    $query .= " WHERE b.kategori_id = '$filter_kategori'";
}

$result = mysqli_query($mysqli, $query);
if (!$result) {
    die("Query error: " . mysqli_error($mysqli));
}

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=data_barang.xls");

echo "------------------------------------------------------------------------------------------------------------\n";
echo "Data Barang\n";
echo "------------------------------------------------------------------------------------------------------------\n";
echo "No\tID Kategori\tNama Barang\tKategori\tJumlah Stok\tHarga\tTanggal Masuk\n";
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    echo $no++ . "\t" . 
         $row['kategori_id'] . "\t" .
         $row['nama'] . "\t" .
         $row['nama_kategori'] . "\t" .
         $row['jumlahstok'] . "\t" .
         $row['harga'] . "\t" .
         $row['tanggalmasuk'] . "\n";
}
?>
