<?php
include("config.php");

if (isset($_POST['tambahbarang'])) {
    $nama = $_POST['nama'];
    $kategori_id = $_POST['kategori_id'];
    $jumlahstok = $_POST['jumlahstok'];
    $harga = $_POST['harga'];
    $tanggalmasuk = $_POST['tanggalmasuk'];

    // Validasi data
    if (empty($nama) || empty($kategori_id) || empty($jumlahstok) || empty($harga) || empty($tanggalmasuk)) {
        echo "
            <script>
                alert('Semua data wajib diisi!');
                document.location.href = 'tambahbarang.php';
            </script>
        ";
        exit;
    }

    if (!preg_match("/^[a-zA-Z\s]+$/", $nama)) {
        echo "
            <script>
                alert('Nama hanya boleh berisi huruf!');
                document.location.href = 'tambahbarang.php';
            </script>
        ";
        exit;
    }

    if ($jumlahstok <= 0 || $harga <= 0) {
        echo "
            <script>
                alert('Jumlah stok dan harga harus lebih dari 0!');
                document.location.href = 'tambahbarang.php';
            </script>
        ";
        exit;
    }

    $query = "INSERT INTO tabel_barang (nama, kategori_id, jumlahstok, harga, tanggalmasuk) 
              VALUES ('$nama', '$kategori_id', '$jumlahstok', '$harga', '$tanggalmasuk')";
    
    $result = mysqli_query($mysqli, $query);

    if ($result) {
        echo "
            <script>
                alert('Barang berhasil ditambahkan!');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal menambahkan barang: " . mysqli_error($mysqli) . "' );
                document.location.href = 'tambahbarang.php';
            </script>
        ";
    }
} else {
    echo "
        <script>
            alert('Akses ditolak!');
            document.location.href = 'index.php';
        </script>
    ";
}
