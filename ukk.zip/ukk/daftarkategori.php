<?php
include("config.php");

$filter_nama_kategori = isset($_GET['nama_kategori']) ? $_GET['nama_kategori'] : '';

$query = "SELECT * FROM tabel_kategori";
if (!empty($filter_nama_kategori)) {
    $query .= " WHERE nama_kategori LIKE '%$filter_nama_kategori%'";
}

$result = mysqli_query($mysqli, $query);
if (!$result) {
    die("Query error: " . mysqli_error($mysqli));
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategori</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css"
        rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <style>
        h1 {
            color: rgb(43, 43, 58);
            margin-top: 20px;
            text-align: center;
        }

        table {
            width: 80%;
            margin: auto;
            background: #f9f9f9;
            padding: 30px;
            border: 1px solid #ddd;
            border-radius: 8px;
            text-align: center;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 5px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #7e9787;
            color: white;
            text-align: center;
        }

        td {
            text-align: center;
        }

        tr:hover {
            background-color: #C2CFB2;
        }

        body {
            background-color: rgb(216, 223, 215);
        }

        .fab-container {
        position: fixed;
        bottom: 10%;
        right: 20px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .fab {
        width: 50px;
        height: 50px;
        background-color: rgb(22, 84, 192);
        border-radius: 50%;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 20px;
        text-decoration: none;
        transition: background-color 0.3s;
    }

    .fab:hover {
        background-color: rgb(9, 17, 129);
    }

    .fab-export {
        background-color: rgb(29, 188, 8);
    }

    .fab-export:hover {
        background-color: rgb(23, 135, 8);
    }

    .input-group .form-control {
        flex: 1;
        max-width: 300px;
    }

    .input-group .btn {
        margin-left: 5px;
    }
    </style>
</head>

<body>
    <h1>Daftar Kategori</h1><br>
    <div class="filter-container">
    <form method="GET" action="" class="from-inline">
            <input type="text" id="nama_kategori" name="nama_kategori" 
                   class="form-control" 
                   placeholder="Masukkan nama kategori" 
                   value="<?php echo htmlspecialchars($filter_nama_kategori); ?>">
            <button type="submit" >Cari</button>
            <a href="daftarkategori.php" class="btn btn-warning">Reset</a>
        </div>
    </form>
</div>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Kategori</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($kategori = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $kategori['id'] . "</td>";
                echo "<td>" . $kategori['nama_kategori'] . "</td>";
                echo "<td class='action-buttons'>
                    <a href='hapuskategori.php?id=" . $kategori['id'] . "' class='btn btn-danger' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")'>Hapus</a>
                </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
    <div class="fab-container">
        <a href="tambahkategori.php" class="fab" title="Tambah Kategori">+</a>
    </div>
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <li class="page-item">
                <a class="page-link" href="index.php">Previous</a>
            </li>
            <li class="page-item"><a class="page-link" href="index.php">1</a></li>
            <li class="page-item"><a class="page-link" href="daftarkategori.php">2</a></li>
            <li class="page-item disabled">
                <a class="page-link">Next</a>
            </li>
        </ul>
    </nav>
</body>

</html>