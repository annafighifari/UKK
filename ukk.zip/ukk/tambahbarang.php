<?php
include("config.php");

$query_kategori = "SELECT id, nama_kategori FROM tabel_kategori";
$result_kategori = mysqli_query($mysqli, $query_kategori);

if (!$result_kategori) {
    die("Query error: " . mysqli_error($mysqli));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            max-width: 400px;
            margin: auto;
            background: #f9f9f9;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input, select {
            width: 95%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            color: white;
            background-color: #4CAF50;
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
        a {
            width: 91%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
        }
        body {
            background-color: rgb(216, 223, 215);
        }
        </style>
</head>
<body>
    <h1>Tambah Barang</h1>
    <form action="prosestambahbarang.php" method="POST">
        <label for="nama">Nama Barang:</label>
        <input type="text" id="nama" name="nama" placeholder="Masukkan nama barang" required>

        <label for="kategori_id">Kategori:</label>
        <select id="kategori_id" name="kategori_id" required>
            <option value="">Pilih Kategori</option>
            <?php
            while ($kategori = mysqli_fetch_assoc($result_kategori)) {
                echo "<option value='" . $kategori['id'] . "'>" . $kategori['nama_kategori'] . "</option>";
            }
            ?>
        </select>

        <label for="jumlahstok">Jumlah:</label>
        <input type="number" id="jumlahstok" name="jumlahstok" placeholder="Masukkan jumlah barang" required>

        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" placeholder="Masukkan harga barang" required>

        <label for="tanggalmasuk">Tanggal:</label>
        <input type="date" id="tanggalmasuk" name="tanggalmasuk" required>
        <div class="vstack gap-2 col-md-5 mx-auto">
        <button type="submit" name="tambahbarang">Tambah Barang</button>
        <a href="index.php" class="btn btn-warning">Kembali ke Daftar Barang</a>
        </div>
    </form>
</body>
</html>
