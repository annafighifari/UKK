<?php
include("config.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "DELETE FROM tabel_barang WHERE id = $id";
    $result = mysqli_query($mysqli, $query);

    if ($result) {
        echo "
            <script>
                alert('Data berhasil dihapus');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal menghapus data: " . mysqli_error($mysqli) . "');
                document.location.href = 'index.php';
            </script>
        ";
    }
} else {
    header("Location: index.php");
    exit();
}
?>
