<?php
include("config.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT * FROM tabel_barang WHERE id = $id";
    $result = mysqli_query($mysqli, $query);
    $barang = mysqli_fetch_assoc($result);
} else {
    header("Location: index.php");
    exit();
}

$kategori_result = mysqli_query($mysqli, "SELECT * FROM tabel_kategori");
if (!$kategori_result) {
    die("Query error: " . mysqli_error($mysqli));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            max-width: 400px;
            margin: auto;
            background: #f9f9f9;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input, select {
            width: 95%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            color: white;
            background-color: #4CAF50;
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
        a {
            width: 91%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
        }
        body {
            background-color: rgb(216, 223, 215);
        }
</style>
</head>
<body>
    <h1>Edit Barang</h1>
    <form action="proseseditbarang.php" method="POST">
        <input type="hidden" name="id" value="<?= $barang['id'] ?>">

        <label for="nama">Nama Barang:</label>
        <input type="text" id="nama" name="nama" value="<?= $barang['nama'] ?>" required>

        <label for="kategori">Kategori:</label>
        <select id="kategori" name="kategori" required>
            <?php
            while ($kategori = mysqli_fetch_assoc($kategori_result)) {
                $selected = $barang['kategori_id'] == $kategori['id'] ? 'selected' : '';
                echo "<option value='" . $kategori['id'] . "' $selected>" . $kategori['nama_kategori'] . "</option>";
            }
            ?>
        </select>

        <label for="jumlahstok">Jumlah:</label>
        <input type="number" id="jumlahstok" name="jumlahstok" value="<?= $barang['jumlahstok'] ?>" required>

        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" value="<?= $barang['harga'] ?>" required>

        <label for="tanggalmasuk">Tanggal:</label>
        <input type="date" id="tanggalmasuk" name="tanggalmasuk" value="<?= $barang['tanggalmasuk'] ?>" required>
        <div class="vstack gap-2 col-md-5 mx-auto">
        <button type="submit" name="updatebarang">Simpan Perubahan</button>
        <a href="index.php" class="btn btn-warning">Kembali</a>
        </div>
    </form>
</body>
</html>

