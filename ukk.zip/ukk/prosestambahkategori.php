<?php
include("config.php");

if (isset($_POST["tambahkategori"])) {
    $nama_kategori = mysqli_real_escape_string($mysqli, $_POST["nama_kategori"]);

    $query = "INSERT INTO tabel_kategori (nama_kategori) VALUES ('$nama_kategori')";

    $result = mysqli_query($mysqli, $query);

    if ($result) {
        echo "
            <script>
                alert('Berhasil menambahkan kategori!');
                document.location.href = 'daftarkategori.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Gagal menambahkan kategori: " . mysqli_error($mysqli) . "');
                document.location.href = 'daftarkategori.php';
            </script>
        ";
    }
} else {
    header("Location: daftarkategori.php");
    exit();
}
?>
