<?php
include("config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tambah Kategori</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            max-width: 400px;
            margin: auto;
            background: #f9f9f9;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        a {
            display: block;
            text-align: center;
            margin-left: 10%;
            width:92%;
            
        }
        body {
            background-color:rgb(216, 223, 215);
        }
    </style>
</head>
<body>
    <h1>Tambah Kategori</h1>
    <form action="prosestambahkategori.php" method="POST">
        <label for="nama_kategori">Nama Kategori:</label>
        <input type="text" id="nama_kategori" name="nama_kategori" placeholder="Masukkan Nama Kategori" required>

        <button type="submit" name="tambahkategori">Tambah Kategori</button>
        <a href="daftarkategori.php" class="btn btn-warning">Kembali ke Daftar Kategori</a>

    </form>
</body>
</html>