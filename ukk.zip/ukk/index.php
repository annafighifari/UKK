<?php
include("config.php");

$kategori_result = mysqli_query($mysqli, "SELECT * FROM tabel_kategori");
if (!$kategori_result) {
    die("Query error: " . mysqli_error($mysqli));
}

$filter_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : '';

$filter_nama = isset($_GET['nama']) ? $_GET['nama'] : '';

$query = "SELECT b.id, b.nama, k.id AS kategori_id, k.nama_kategori, b.jumlahstok, b.harga, b.tanggalmasuk 
          FROM tabel_barang b 
          JOIN tabel_kategori k ON b.kategori_id = k.id";

$conditions = [];
if (!empty($filter_kategori)) {
    $conditions[] = "b.kategori_id = '$filter_kategori'";
}
if (!empty($filter_nama)) {
    $conditions[] = "b.nama LIKE '%$filter_nama%'";
}
if (!empty($conditions)) {
    $query .= " WHERE " . implode(' AND ', $conditions);
}

$result = mysqli_query($mysqli, $query);
if (!$result) {
    die("Query error: " . mysqli_error($mysqli));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css"
        rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
</head>
<style>
    body {
        background-color: rgb(216, 223, 215);
    }

    h1 {
        color: rgb(43, 43, 58);
        margin-top: 20px;
        text-align: center;
    }

    table {
        width: 80%;
        margin: auto;
        background: #f9f9f9;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        text-align: center;
        border-collapse: collapse;
        margin-top: 20px;
        margin-bottom: 5px;
    }

    table,th,td {
        border: 1px solid #ddd;
        padding: 8px;
    }

    th {
        background-color: #7e9787;
        color: white;
        text-align: center;
    }

    td {
        text-align: center;
    }

    tr:hover {
        background-color: #C2CFB2;
    }

    .fab-container {
        position: fixed;
        bottom: 10%;
        right: 20px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .fab {
        width: 50px;
        height: 50px;
        background-color: rgb(22, 84, 192);
        border-radius: 50%;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 20px;
        text-decoration: none;
        transition: background-color 0.3s;
    }

    .fab:hover {
        background-color: rgb(9, 17, 129);
    }

    .fab-export {
        background-color: rgb(29, 188, 8);
    }

    .fab-export:hover {
        background-color: rgb(23, 135, 8);
    }

    .input-group .form-control {
        flex: 1;
        max-width: 300px;
    }

    .input-group .btn {
        margin-left: 5px;
    }
</style>
<body>
    <h1>Daftar Barang</h1><br>
    <div class="filter-container">
        <form method="GET" action="" class="from-inline">
            <label for="kategori">Filter Kategori:</label>
            <select id="kategori" name="kategori">
                <option value="">Semua Kategori</option>
                <?php
                while ($kategori = mysqli_fetch_assoc($kategori_result)) {
                    $selected = $filter_kategori == $kategori['id'] ? 'selected' : '';
                    echo "<option value='" . $kategori['id'] . "' $selected>" . $kategori['nama_kategori'] . "</option>";
                }
                ?>
            </select>
            <label for="nama">Cari:</label>
            <input type="nama" id="nama" name="nama" placeholder="Cari Nama Barang" value="<?php echo htmlspecialchars($filter_nama); ?>">

            <button type="submit">Tampilkan</button>
        </form>
    </div>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Barang</th>
                <th>Kategori ID</th>
                <th>Kategori</th>
                <th>Stok</th>
                <th>Harga / Pcs</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($barang = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $no++ . "</td>";
                echo "<td>" . $barang['nama'] . "</td>";
                echo "<td>" . $barang['kategori_id'] . "</td>";
                echo "<td>" . $barang['nama_kategori'] . "</td>";
                echo "<td>" . $barang['jumlahstok'] . "</td>";
                echo "<td>" . $barang['harga'] . "</td>";
                echo "<td>" . $barang['tanggalmasuk'] . "</td>";
                echo "<td>
                <a href='editbarang.php?id=" . $barang['id'] . "' class='btn btn-warning' id='link'>Edit</a>
                <a href='hapusbarang.php?id=" . $barang['id'] . "' class='btn btn-danger' id='link'onclick='return confirm(\"Apakah Anda Yakin Menghapus Data Ini?\")'>Hapus</a>
              </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="fab-container">
        <a href="tambahbarang.php" class="fab" title="Tambah Barang">+</a>
        <a href="exportexcel.php?kategori=<?php echo $filter_kategori; ?>"
            class="fab fab-export" title="Ekspor ke Excel">⇩</a>
    </div>

    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <li class="page-item disabled">
                <a class="page-link">Previous</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="daftarkategori.php">2</a></li>
            <li class="page-item">
                <a class="page-link" href="daftarkategori.php">Next</a>
            </li>
        </ul>
    </nav>
</body>

</html>